<div class="container">
  <div class="row">
    <div class="panel panel-default mt-5 w-100">
      <div class="panel-heading">Users</div>
      <div class="panel-body">
        <table id="example" class="display">
          <thead>
            <tr>
              <th>User id</th>
              <th>Name</th>
              <th>Email</th>
              <th>Message</th>
              <th>QR code</th>
            </tr>
          </thead>
          <tbody>
            <?php
            global $wpdb;
            $table_name = $wpdb->prefix . "qr_code";
            $result = $wpdb->get_results("SELECT * FROM $table_name");
            if (!empty($result)) {
              foreach ($result as $r) {
            ?>
                <tr>
                  <td><?php echo $r->id ?></td>
                  <td><?php echo $r->name ?></td>
                  <td><?php echo $r->email ?></td>
                  <td><?php echo $r->message ?></td>
                  <td><img src="<?php echo plugin_dir_url(__FILE__) . 'temp/' . basename($r->qr_image); ?>" width="100"></td>
                  
                </tr>
            <?php
              }
            }
            ?>
          </tbody>
          <tfoot>
            <tr>
              <th>id</th>
              <th>Name</th>
              <th>Email</th>
              <th>Message</th>
            </tr>
          </tfoot>
        </table>


      </div>
    </div>

  </div>
</div>

<script>
    jQuery(document).ready(function () {
    jQuery('#example').DataTable();
    
}); 
</script>