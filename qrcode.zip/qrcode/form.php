<?php
if (!defined("ABSPATH")) {
    die("can't access");
}
add_shortcode('qr_form', 'qr_form');

function qr_form()
{
    ob_start();
?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <div class="container py-3">

        <div class="row">
            <div class="col-md-12">
                <div class="row justify-content-center">
                    <div class="col-md-12">
                        <!-- form user info -->
                            <div class="w-100 card card-outline-secondary">
                                <div class="card-header">
                                    <h3 class="mb-0">User Information</h3>
                                </div>
                                <?php
                                $first_name = "Babaji";
                                $email = "email@gmail.com";
                                $message = "babajitechnical";

                                if (isset($_POST["btnsubmit"])) {
                                    $first_name = $_POST["first_name"];
                                    $email = $_POST["email"];
                                    $message = $_POST["message"];
                                }
                                ?>
                                <div class="card-body">
                                    <form autocomplete="off" class="form" role="form" action="" method="post">
                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label form-control-label">First name</label>
                                            <div class="col-lg-9">
                                                <input class="form-control" type="text"name="first_name">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label form-control-label">Email</label>
                                            <div class="col-lg-9">
                                                <input class="form-control" type="email"  name="email">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label form-control-label">Message</label>
                                            <div class="col-lg-9">
                                                <input class="form-control" type="text" name="message">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-lg-3 col-form-label form-control-label"></label>
                                            <div class="col-lg-9">
                                                <input class="btn btn-primary" type="submit" name="btnsubmit" value="Generate QR Code">
                                            </div>
                                        </div>
                                    </form>
                                    <?php
                                    include_once plugin_dir_path(__FILE__) . "phpqrcode/qrlib.php";

                                    $PNG_TEMP_DIR = plugin_dir_path(__FILE__) . "temp/";

                                    if (!file_exists($PNG_TEMP_DIR)) {
                                        mkdir($PNG_TEMP_DIR);
                                    }

                                    $filename = $PNG_TEMP_DIR . 'test.png';
                                    if (isset($_POST["btnsubmit"])) {
                                        $first_name = $_POST["first_name"];
                                        $email = $_POST["email"];
                                        $message = $_POST["message"];

                                        $codeString = $first_name . "\n";
                                        $codeString .= $email . "\n";
                                        $codeString .= $message . "\n";

                                        $filename = $PNG_TEMP_DIR . 'test' . md5($codeString) . '.png';

                                        $id = 'UDI' . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT); // Generate a 
                                        global $wpdb;
                                        $table_name = $wpdb->prefix . 'qr_code'; // Replace 'qr_code' with the actual table name
                                        $result = $wpdb->insert(
                                            $table_name,
                                            array(
                                                'id' => $id,
                                                'name' => $first_name,
                                                'email' => $email,
                                                'message' => $message,
                                                'qr_image' => $filename
                                            )
                                        );
                                        
                                        if ($result) {
                                            echo '<script>alert("Your QR Code is ready!");</script>';
                                        } else {
                                            $error_message = $wpdb->last_error;
                                            echo '<script>alert("Failed to insert data: ' . $error_message . '");</script>';
                                        }
                                        

                                        QRcode::png($codeString, $filename);

                                        $download_path = plugin_dir_url(__FILE__) . 'temp/' . basename($filename);
                                        $image_path = plugin_dir_url(__FILE__) . 'temp/' . basename($filename);

                                        // echo '<a href="' . $download_path . '" download>Download</a>';
                                        echo '<img src="' . $image_path . '">';
                                    }
                                    ?>

                                </div>
                            </div><!-- /form user info -->
                    </div>
                </div>

            </div><!--/col-->
        </div><!--/row-->

    </div><!--/container-->
<?php
    return ob_get_clean();
} ?>