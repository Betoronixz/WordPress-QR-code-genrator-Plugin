<?php
/*Plugin Name: QR CODE 
Description: 
Version: 1.0
Author: Traffic Tail
*/
if (!defined("ABSPATH")) {
    die("can't access");
}

register_activation_hook(__FILE__, 'tt_scm_create_table');
function tt_scm_create_table()
{
    // Get global $wpdb object
    global $wpdb;

    // Set table name and create SQL query
    $table_name = $wpdb->prefix . 'qr_code';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        $sql = "CREATE TABLE $table_name (
            id VARCHAR(10) PRIMARY KEY,
            name VARCHAR(255),
            email VARCHAR(255),
            message VARCHAR(255),
            qr_image VARCHAR(255)
          );
          
          ";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }
}

// adding on menu
add_action("admin_menu", "scm_custom_menu");
function scm_custom_menu()
{
    add_menu_page(
        "Qr Code",
        "Qr Code",
        "manage_options",
        "qr-code",
        "scmdash",
        "dashicons-index-card",
        6
    );
    // add_submenu_page(
    //     "tt-scm",
    //     "Studente-data",
    //     "Student Data",
    //     "manage_options",
    //     "scm-data",
    //     "scmdata"
    // );
}

function idadmin()
{
    if (isset($_GET['page']) && ($_GET['page'] == 'qr-code')) {
        wp_enqueue_style("my-table-qr", "//cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css", "", '');
        wp_enqueue_style("my-table-qr-bs", "https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css", "", '');
        wp_enqueue_script("my-table-qr-js", "//cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js", "", '');
    }
}
add_action("admin_enqueue_scripts", "idadmin");


function scmdata()
{
    include plugin_dir_path(__FILE__) . "/admin/scmdata.php";
}

function scmdash()
{
    include plugin_dir_path(__FILE__) . "/admin_table.php";
}

add_action('admin_enqueue_scripts', 'tt_scm_admin_script');
function tt_scm_admin_script()
{
    if (isset($_GET['page']) && ($_GET['page'] == 'tt-scm' || $_GET['page'] == 'scm-data')) {
        wp_enqueue_style('custom-scmstyle', plugin_dir_url(__FILE__) . 'assets/style.css');
    }
}






include plugin_dir_path(__FILE__) . "form.php";
